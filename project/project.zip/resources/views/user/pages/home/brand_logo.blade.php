<div class="brand-logo-section mt-100">
            <div class="brand-logo-inner">
                <div class="container">
                    <div class="brand-logo-container overflow-hidden">
                        <div class="scroll-horizontal row align-items-center flex-nowrap">
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/1.png" alt="img">
                                </a>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/2.png" alt="img">
                                </a>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/3.png" alt="img">
                                </a>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/4.png" alt="img">
                                </a>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/5.png" alt="img">
                                </a>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6" data-aos="fade-up"
                                data-aos-duration="700">
                                <a href="index.html"
                                    class="brand-logo d-flex align-items-center justify-content-center">
                                    <img src="{{ asset('themes/user') }}/img/brand/6.png" alt="img">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>