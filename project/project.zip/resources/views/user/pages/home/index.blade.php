<x-user.layouts.app>
    <main id="MainContent" class="content-for-layout">
       
        @include('user.pages.home.slideshow')
        @include('user.pages.home.trusted_badge')
        @include('user.pages.home.banner')
        @include('user.pages.home.featured')
        @include('user.pages.home.shop_by_category')
        @include('user.pages.home.video')
        @include('user.pages.home.single_banner')
        @include('user.pages.home.latest_blog')
        @include('user.pages.home.brand_logo')
      
    </main>
</x-user.layouts.app>