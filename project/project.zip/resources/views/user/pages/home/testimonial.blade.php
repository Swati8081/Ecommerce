<div class="testimonial-section mt-100 overflow-hidden home-section">
    <div class="testimonial-inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-12" data-aos="fade-right" data-aos-duration="700">
                    <div class="section-header">
                        <h2 class="section-heading primary-color">What customer say</h2>
                        <p class="section-subheading">
                            The services provided by the officials was smooth and satisfactory. Products and
                            goods delivered were up to satisfaction.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-12 col-12" data-aos="fade-left"
                    data-aos-duration="700">
                    <div class="testimonial-container position-relative">
                        <div class="testimonial-slideshow common-slider"
                            data-slick='{
                                "slidesToShow": 1, 
                                "slidesToScroll": 1,
                                "dots": false,
                                "arrows": true
                            }'>
                            <div class="testimonial-item">
                                <div class="testimonial-icon-wrap d-flex align-items-center">
                                    <div class="testimonial-icon-quote">
                                        <svg width="40" height="29" viewbox="0 0 40 29"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M0 28.99L11.7 0H19.5L12.22 28.99H0ZM20.28 28.99L32.11 0H39.91L32.5 28.99H20.28Z"
                                                fill="#00234D"></path>
                                        </svg>
                                    </div>
                                    <div class="testimonial-icon-star d-flex align-items-center ms-3">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                    </div>
                                </div>
                                <p class="testimonial-review my-4 text_16">
                                    “ I am purchasing furniture from Bisum since the last 6 years. I love
                                    their
                                    prompt service and so far I have faced no complaints with their
                                    furniture.”
                                </p>
                                <div class="testimonial-reviewer d-flex align-items-center">
                                    <div class="reviewer-img">
                                        <img src="{{ asset('themes/user') }}/img/testimonial/john.jpg"
                                            alt="img">
                                    </div>
                                    <div class="reviewer-info ms-4">
                                        <h4 class="reviewer-name heading_18 mb-2 primary-color">Floyd Miles
                                        </h4>
                                        <p class="reviewer-desig text_14 m-0">Executive, Hypebeast</p>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-icon-wrap d-flex align-items-center">
                                    <div class="testimonial-icon-quote">
                                        <svg width="40" height="29" viewbox="0 0 40 29"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M0 28.99L11.7 0H19.5L12.22 28.99H0ZM20.28 28.99L32.11 0H39.91L32.5 28.99H20.28Z"
                                                fill="#00234D"></path>
                                        </svg>
                                    </div>
                                    <div class="testimonial-icon-star d-flex align-items-center ms-3">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                    </div>
                                </div>
                                <p class="testimonial-review my-4 text_16">
                                    “ I am purchasing furniture from Bisum since the last 6 years. I love
                                    their
                                    prompt service and so far I have faced no complaints with their
                                    furniture.”
                                </p>
                                <div class="testimonial-reviewer d-flex align-items-center">
                                    <div class="reviewer-img">
                                        <img src="{{ asset('themes/user') }}/img/testimonial/john.jpg"
                                            alt="img">
                                    </div>
                                    <div class="reviewer-info ms-4">
                                        <h4 class="reviewer-name heading_18 mb-2 primary-color">Floyd Miles
                                        </h4>
                                        <p class="reviewer-desig text_14 m-0">Executive, Hypebeast</p>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-icon-wrap d-flex align-items-center">
                                    <div class="testimonial-icon-quote">
                                        <svg width="40" height="29" viewbox="0 0 40 29"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M0 28.99L11.7 0H19.5L12.22 28.99H0ZM20.28 28.99L32.11 0H39.91L32.5 28.99H20.28Z"
                                                fill="#00234D"></path>
                                        </svg>
                                    </div>
                                    <div class="testimonial-icon-star d-flex align-items-center ms-3">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                        <img src="{{ asset('themes/user') }}/img/icon/star.png"
                                            alt="img">
                                    </div>
                                </div>
                                <p class="testimonial-review my-4 text_16">
                                    “ I am purchasing furniture from Bisum since the last 6 years. I love
                                    their
                                    prompt service and so far I have faced no complaints with their
                                    furniture.”
                                </p>
                                <div class="testimonial-reviewer d-flex align-items-center">
                                    <div class="reviewer-img">
                                        <img src="{{ asset('themes/user') }}/img/testimonial/john.jpg"
                                            alt="img">
                                    </div>
                                    <div class="reviewer-info ms-4">
                                        <h4 class="reviewer-name heading_18 mb-2 primary-color">Floyd Miles
                                        </h4>
                                        <p class="reviewer-desig text_14 m-0">Executive, Hypebeast</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="activate-arrows show-arrows-always article-arrows arrows-white"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>