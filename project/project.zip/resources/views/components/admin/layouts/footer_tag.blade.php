<script src="{{asset('themes/admin')}}/vendor/global/global.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/apexchart/apexchart.js"></script>

<!-- Dashboard 1 -->
 
<script src="{{asset('themes/admin')}}/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/datatables/js/dataTables.buttons.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/datatables/js/buttons.html5.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/datatables/js/jszip.min.js"></script>
<script src="{{asset('themes/admin')}}/js/plugins-init/datatables.init.js"></script>

<!-- Apex Chart -->
<script src="{{asset('themes/admin')}}/js/custom.js"></script>
<script src="{{asset('themes/admin')}}/js/deznav-init.js"></script>
<script src="{{asset('themes/admin')}}/js/demo.js"></script>
{{-- <script src="{{asset('themes/admin')}}/js/styleSwitcher.js"></script> --}}

<!-- tagify -->
<script src="{{asset('themes/admin')}}/vendor/tagify/dist/tagify.js"></script>

<script src="{{asset('themes/admin')}}/vendor/global/global.min.js"></script>
<script src="{{asset('themes/admin')}}/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
