<?php


require __DIR__.'/admin/web.php';
require __DIR__.'/user/web.php';
